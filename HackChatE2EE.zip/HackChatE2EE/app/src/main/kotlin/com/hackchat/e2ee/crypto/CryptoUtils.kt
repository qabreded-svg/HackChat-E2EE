package com.hackchat.e2ee.crypto

import android.util.Base64
import com.google.crypto.tink.Aead
import com.google.crypto.tink.KeyTemplates
import com.google.crypto.tink.Keyset
import com.google.crypto.tink.aead.AeadKeyTemplates
import com.google.crypto.tink.aead.AeadParameters
import com.google.crypto.tink.aead.ChaCha20Poly1305KeyManager
import com.google.crypto.tink.integration.gcpkms.GcpKmsClient
import com.google.crypto.tink.proto.AesCtrHmacAead
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * Cryptographic utilities for HCE2EE-1 protocol.
 * Handles key derivation, encryption, decryption, and fingerprinting.
 */
object CryptoUtils {

    private const val ALGORITHM = "AES"
    private const val CIPHER_MODE = "AES/GCM/NoPadding"
    private const val GCM_TAG_LENGTH = 128
    private const val GCM_NONCE_LENGTH = 96 // 12 bytes
    private const val KEY_SIZE = 256

    /**
     * Derives a 256-bit encryption key from a passphrase using Argon2id.
     * Salt is derived from roomName and server address.
     *
     * @param passphrase The user's passphrase
     * @param roomName The chat room name
     * @param server The server address
     * @return 256-bit (32-byte) encryption key
     */
    fun deriveKey(passphrase: String, roomName: String, server: String): ByteArray {
        // Create salt from roomName + server
        val salt = (roomName + server).toByteArray(Charsets.UTF_8)

        // Use Argon2id for key derivation
        // Since Tink doesn't provide direct Argon2id, we use a simplified approach
        // with PBKDF2 as fallback (production should use proper Argon2id library)
        return deriveKeyWithPBKDF2(passphrase, salt, 32)
    }

    /**
     * PBKDF2-based key derivation (fallback for Argon2id).
     * In production, integrate a proper Argon2id library like Argon2kt.
     */
    private fun deriveKeyWithPBKDF2(
        passphrase: String,
        salt: ByteArray,
        keyLength: Int
    ): ByteArray {
        val spec = javax.crypto.spec.PBEKeySpec(
            passphrase.toCharArray(),
            salt,
            100000, // iterations
            keyLength * 8
        )
        val factory = javax.crypto.SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        return factory.generateSecret(spec).encoded
    }

    /**
     * Encrypts a message using AES-256-GCM with a random nonce.
     *
     * @param plaintext The message to encrypt
     * @param key The 256-bit encryption key
     * @return Encrypted message in format: [e2ee:v1]:<base64(nonce)>:<base64(ciphertext)>
     */
    fun encrypt(plaintext: String, key: ByteArray): String {
        try {
            // Generate random 96-bit nonce
            val nonce = ByteArray(GCM_NONCE_LENGTH / 8)
            SecureRandom().nextBytes(nonce)

            // Create cipher
            val cipher = Cipher.getInstance(CIPHER_MODE)
            val secretKey = SecretKeySpec(key, 0, key.size, ALGORITHM)
            val gcmSpec = GCMParameterSpec(GCM_TAG_LENGTH, nonce)
            cipher.init(Cipher.ENCRYPT_MODE, secretKey, gcmSpec)

            // Encrypt
            val ciphertext = cipher.doFinal(plaintext.toByteArray(Charsets.UTF_8))

            // Encode as base64
            val encodedNonce = Base64.encodeToString(nonce, Base64.NO_WRAP)
            val encodedCiphertext = Base64.encodeToString(ciphertext, Base64.NO_WRAP)

            return "[e2ee:v1]:$encodedNonce:$encodedCiphertext"
        } catch (e: Exception) {
            throw CryptoException("Encryption failed", e)
        }
    }

    /**
     * Decrypts a message in HCE2EE-1 format.
     *
     * @param encryptedMessage Message in format: [e2ee:v1]:<base64(nonce)>:<base64(ciphertext)>
     * @param key The 256-bit encryption key
     * @return Decrypted plaintext, or null if decryption fails
     */
    fun decrypt(encryptedMessage: String, key: ByteArray): String? {
        return try {
            if (!encryptedMessage.startsWith("[e2ee:v1]:")) {
                return null
            }

            val parts = encryptedMessage.substring(10).split(":")
            if (parts.size != 2) {
                return null
            }

            val nonce = Base64.decode(parts[0], Base64.NO_WRAP)
            val ciphertext = Base64.decode(parts[1], Base64.NO_WRAP)

            // Create cipher
            val cipher = Cipher.getInstance(CIPHER_MODE)
            val secretKey = SecretKeySpec(key, 0, key.size, ALGORITHM)
            val gcmSpec = GCMParameterSpec(GCM_TAG_LENGTH, nonce)
            cipher.init(Cipher.DECRYPT_MODE, secretKey, gcmSpec)

            // Decrypt
            val plaintext = cipher.doFinal(ciphertext)
            String(plaintext, Charsets.UTF_8)
        } catch (e: Exception) {
            null
        }
    }

    /**
     * Generates a SHA-256 fingerprint from the encryption key.
     * Displayed in shortened format (e.g., A7F3-C9D2).
     *
     * @param key The encryption key
     * @return Shortened fingerprint (8 characters + dash)
     */
    fun generateFingerprint(key: ByteArray): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val hash = digest.digest(key)

        // Take first 4 bytes and convert to hex
        val hex = hash.take(4).joinToString("") { "%02X".format(it) }

        // Format as XXXX-XXXX
        return "${hex.substring(0, 4)}-${hex.substring(4, 8)}"
    }

    /**
     * Generates an encrypted proof message for E2EE handshake.
     *
     * @param key The encryption key
     * @return Encrypted proof message
     */
    fun generateProofMessage(key: ByteArray): String {
        val random = ByteArray(16)
        SecureRandom().nextBytes(random)
        val proof = "HCE2EE-PROOF:" + Base64.encodeToString(random, Base64.NO_WRAP)
        return encrypt(proof, key)
    }

    /**
     * Checks if a message is encrypted in HCE2EE-1 format.
     */
    fun isEncrypted(message: String): Boolean {
        return message.startsWith("[e2ee:v1]:")
    }

    /**
     * Checks if a message is a proof message.
     */
    fun isProofMessage(message: String): Boolean {
        return message.startsWith("[e2ee-proto:v1]")
    }
}

/**
 * Custom exception for cryptographic operations.
 */
class CryptoException(message: String, cause: Throwable? = null) : Exception(message, cause)
