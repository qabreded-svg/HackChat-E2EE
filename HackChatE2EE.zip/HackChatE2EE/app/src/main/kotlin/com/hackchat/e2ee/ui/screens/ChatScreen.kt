package com.hackchat.e2ee.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.hackchat.e2ee.R
import com.hackchat.e2ee.model.ChatMessage
import com.hackchat.e2ee.model.ConnectionState
import com.hackchat.e2ee.model.User
import java.time.format.DateTimeFormatter

@Composable
fun ChatScreen(
    roomName: String,
    username: String,
    fingerprint: String?,
    messages: List<ChatMessage>,
    users: List<User>,
    connectionState: ConnectionState,
    onSendMessage: (String) -> Unit,
    onBack: () -> Unit,
    onThemeToggle: () -> Unit
) {
    var messageInput by remember { mutableStateOf("") }
    var showUsersList by remember { mutableStateOf(false) }
    val clipboardManager = LocalClipboardManager.current
    val listState = rememberLazyListState()

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Header
        ChatHeader(
            roomName = roomName,
            connectionState = connectionState,
            onBack = onBack,
            onCopyRoom = {
                clipboardManager.setText(AnnotatedString("hack.chat/?$roomName"))
            },
            onShowUsers = { showUsersList = !showUsersList },
            onThemeToggle = onThemeToggle
        )

        // Users List (if shown)
        if (showUsersList) {
            UsersList(
                users = users,
                currentUsername = username,
                currentFingerprint = fingerprint,
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 200.dp)
                    .background(MaterialTheme.colorScheme.surface)
            )
        }

        // Messages List
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 8.dp),
            state = listState
        ) {
            items(messages) { message ->
                MessageItem(message)
            }
        }

        // Input Bar
        ChatInputBar(
            messageInput = messageInput,
            onMessageChange = { messageInput = it },
            onSend = {
                if (messageInput.isNotBlank()) {
                    onSendMessage(messageInput)
                    messageInput = ""
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.surface)
        )
    }
}

@Composable
private fun ChatHeader(
    roomName: String,
    connectionState: ConnectionState,
    onBack: () -> Unit,
    onCopyRoom: () -> Unit,
    onShowUsers: () -> Unit,
    onThemeToggle: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surface)
            .padding(8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        // Back Button
        IconButton(onClick = onBack) {
            Icon(
                imageVector = Icons.Default.ArrowBack,
                contentDescription = stringResource(R.string.back),
                tint = MaterialTheme.colorScheme.onSurface
            )
        }

        // Room Name and Status
        Column(
            modifier = Modifier.weight(1f),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "#$roomName",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = when (connectionState) {
                    ConnectionState.CONNECTED -> stringResource(R.string.connected)
                    ConnectionState.CONNECTING -> stringResource(R.string.connecting)
                    ConnectionState.RECONNECTING -> stringResource(R.string.reconnecting)
                    else -> stringResource(R.string.disconnected)
                },
                style = MaterialTheme.typography.labelSmall,
                color = when (connectionState) {
                    ConnectionState.CONNECTED -> MaterialTheme.colorScheme.primary
                    ConnectionState.ERROR -> MaterialTheme.colorScheme.error
                    else -> MaterialTheme.colorScheme.onSurfaceVariant
                },
                fontSize = 10.sp
            )
        }

        // Copy Room Button
        IconButton(onClick = onCopyRoom) {
            Icon(
                imageVector = Icons.Default.ContentCopy,
                contentDescription = stringResource(R.string.copy_room_link),
                tint = MaterialTheme.colorScheme.onSurface
            )
        }

        // Users Button
        Button(onClick = onShowUsers, modifier = Modifier.padding(4.dp)) {
            Text("👥")
        }

        // Theme Toggle
        Button(onClick = onThemeToggle, modifier = Modifier.padding(4.dp)) {
            Text("🌙")
        }
    }
}

@Composable
private fun MessageItem(message: ChatMessage) {
    val timeFormatter = DateTimeFormatter.ofPattern("HH:mm")
    val timeString = message.timestamp.format(timeFormatter)

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "[$timeString]",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(end = 8.dp)
            )

            if (message.isEncrypted) {
                Text(text = "🔒", modifier = Modifier.padding(end = 4.dp))
            }

            Text(
                text = message.username,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(end = 8.dp)
            )

            if (message.fingerprint != null) {
                Text(
                    text = message.fingerprint,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Text(
            text = message.content,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onBackground,
            modifier = Modifier.padding(start = 8.dp, top = 2.dp)
        )
    }
}

@Composable
private fun UsersList(
    users: List<User>,
    currentUsername: String,
    currentFingerprint: String?,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .verticalScroll(rememberScrollState())
            .padding(8.dp)
    ) {
        Text(
            text = stringResource(R.string.users),
            style = MaterialTheme.typography.titleSmall,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        users.forEach { user ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (user.hasE2EE) "🔒" else "◌",
                    modifier = Modifier.padding(end = 8.dp)
                )
                Text(
                    text = user.username,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.weight(1f)
                )
                if (user.fingerprint != null) {
                    Text(
                        text = user.fingerprint,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        Divider(modifier = Modifier.padding(vertical = 8.dp))

        Text(
            text = stringResource(R.string.you),
            style = MaterialTheme.typography.titleSmall,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = "🔒", modifier = Modifier.padding(end = 8.dp))
            Text(
                text = currentUsername,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.weight(1f)
            )
            if (currentFingerprint != null) {
                Text(
                    text = currentFingerprint,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun ChatInputBar(
    messageInput: String,
    onMessageChange: (String) -> Unit,
    onSend: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .padding(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        OutlinedTextField(
            value = messageInput,
            onValueChange = onMessageChange,
            modifier = Modifier
                .weight(1f)
                .heightIn(min = 48.dp),
            placeholder = { Text("Type message...") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
            singleLine = false,
            maxLines = 3
        )

        Button(
            onClick = onSend,
            modifier = Modifier
                .padding(start = 8.dp)
                .height(48.dp)
        ) {
            Text(stringResource(R.string.send))
        }
    }
}
