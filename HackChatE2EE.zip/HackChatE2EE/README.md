# HackChat E2EE - Native Android Application

A fully native Android application implementing the **HCE2EE-1** protocol for end-to-end encrypted chat on HackChat-compatible servers.

## Features

- **Native Android** - Pure Kotlin + Android SDK (no WebView, no React Native)
- **IRC-Style UI** - Minimal, text-first interface
- **End-to-End Encryption** - Optional client-side E2EE using AES-256-GCM
- **Key Derivation** - Argon2id-based passphrase-to-key conversion
- **User Fingerprints** - SHA-256 fingerprints for user verification
- **Theme Support** - Light and dark themes
- **Secure Storage** - Credentials stored securely (passphrase never stored)
- **WebSocket Support** - Real-time communication with HackChat servers
- **Self-Hosted Support** - Works with public and self-hosted HackChat servers

## Architecture

```
app/src/main/kotlin/com/hackchat/e2ee/
├── ui/
│   ├── MainActivity.kt          # Main activity with navigation
│   ├── screens/
│   │   ├── LoginScreen.kt       # Login/join screen
│   │   └── ChatScreen.kt        # Chat interface
│   └── theme/
│       └── Theme.kt             # Material 3 theme definitions
├── crypto/
│   └── CryptoUtils.kt           # Encryption/decryption logic
├── network/
│   └── HackChatClient.kt        # WebSocket client
├── data/
│   └── PreferencesManager.kt    # Secure preferences storage
└── model/
    └── Models.kt                # Data classes
```

## Building the APK

### Prerequisites

- Android Studio (latest version)
- Android SDK 34+
- Kotlin 1.9.0+
- Gradle 8.1+

### Build Steps

1. **Clone/Extract the project:**
   ```bash
   cd HackChatE2EE
   ```

2. **Open in Android Studio:**
   - File → Open → Select the HackChatE2EE directory

3. **Build the APK:**
   - Build → Build Bundle(s) / APK(s) → Build APK(s)
   - Or use command line:
     ```bash
     ./gradlew assembleRelease
     ```

4. **Locate the APK:**
   - Debug: `app/build/outputs/apk/debug/app-debug.apk`
   - Release: `app/build/outputs/apk/release/app-release.apk`

5. **Install on device:**
   ```bash
   adb install app/build/outputs/apk/release/app-release.apk
   ```

## Usage

### Joining a Room

1. **Launch the app**
2. **Enter connection details:**
   - Server Address: `hack.chat` or custom server URL
   - Room Name: `meta`, `lounge`, etc.
   - Username: Your chosen nickname
   - Passphrase: (Optional) For E2EE encryption

3. **Check "Remember login"** to save credentials (passphrase never stored)
4. **Tap "Join"** to connect

### Sending Messages

- **Plain text:** Type and send normally
- **Encrypted:** If passphrase provided, messages auto-encrypt
- **Shift+Enter:** Add newline
- **Enter:** Send message

### User List

- Tap the **👥** button to see connected users
- **🔒** = User has matching passphrase (E2EE enabled)
- **◌** = Unknown encryption state
- Fingerprints shown for verification

### Theme Toggle

- Tap **🌙** to toggle between light and dark themes
- Preference saved automatically

## Security Model

### What It Protects

- ✅ Server-side message inspection
- ✅ Network sniffing (encrypted payload)
- ✅ Passive logging

### What It Does NOT Protect

- ❌ Compromised client devices
- ❌ Users sharing passphrase
- ❌ Malicious group members
- ❌ Perfect forward secrecy (group-shared-secret model)

### Key Points

- **Passphrase never sent to server**
- **Passphrase never stored on device**
- **Encryption key derived locally** using Argon2id
- **Each message has random nonce** (AES-256-GCM)
- **Fingerprints for manual verification** only

## Encryption Details

### Key Derivation
```
key = Argon2id(passphrase, salt = roomName + server)
Output: 256-bit key
```

### Encryption Algorithm
```
Algorithm: AES-256-GCM
Nonce: 96-bit (random per message)
Tag: 128-bit
```

### Message Format
```
[e2ee:v1]:<base64(nonce)>:<base64(ciphertext)>
```

### Decryption Failure
```
[Encrypted message - wrong passphrase]
```

## Dependencies

- **Android Core:** androidx.core, androidx.appcompat
- **Jetpack Compose:** Material 3, Navigation
- **Networking:** OkHttp 4.11.0
- **Cryptography:** Tink (Google's cryptography library)
- **JSON:** Gson
- **Coroutines:** kotlinx.coroutines
- **Storage:** androidx.datastore

## Permissions

- `INTERNET` - WebSocket connections
- `ACCESS_NETWORK_STATE` - Network status

## Minimum Requirements

- **Android:** 7.0+ (API 24)
- **Target:** Android 14+ (API 34)
- **RAM:** 100MB+
- **Storage:** 20MB+

## Troubleshooting

### Connection Failed
- Check server address format (e.g., `hack.chat`)
- Verify internet connection
- Try a different room

### Messages Not Decrypting
- Ensure all users use the same passphrase
- Check passphrase spelling and case sensitivity
- Verify room name and server address match

### App Crashes
- Clear app cache: Settings → Apps → HackChat E2EE → Storage → Clear Cache
- Reinstall the app
- Check logcat for detailed errors

## Development

### Adding Features

1. **New UI screens:** Add to `ui/screens/`
2. **New crypto operations:** Extend `crypto/CryptoUtils.kt`
3. **New network commands:** Update `network/HackChatClient.kt`
4. **New preferences:** Add to `data/PreferencesManager.kt`

### Testing

```bash
./gradlew test              # Unit tests
./gradlew connectedAndroidTest  # Instrumented tests
```

## License

This project implements the HCE2EE-1 protocol specification.

## Support

For issues or questions:
1. Check the troubleshooting section
2. Review the HCE2EE-1 protocol specification
3. Check HackChat documentation

## Notes

- This is a reference implementation of HCE2EE-1
- Security depends on passphrase entropy
- Always verify fingerprints for new users
- Do not share passphrases in insecure channels
