# HackChat E2EE - Quick Start Guide

## 🚀 Build in 3 Steps

### Step 1: Install Android Studio
Download from https://developer.android.com/studio and install.

### Step 2: Open Project
1. Launch Android Studio
2. File → Open → Select `HackChatE2EE` folder
3. Wait for Gradle sync

### Step 3: Build APK
```bash
# Terminal in project directory
./gradlew assembleRelease
```

**Output:** `app/build/outputs/apk/release/app-release.apk`

---

## 📱 Install on Device

### Option A: Android Studio
1. Connect Android device via USB
2. Build → Build Bundle(s) / APK(s) → Build APK(s)
3. Run → Run 'app'

### Option B: Command Line
```bash
adb install app/build/outputs/apk/release/app-release.apk
```

---

## 🎮 Using the App

### Join a Room
1. **Server:** `hack.chat`
2. **Room:** `meta` (or any room name)
3. **Username:** Your nickname
4. **Passphrase:** (Optional, for E2EE)
5. Tap **Join**

### Send Messages
- Type message → Tap **Send**
- Messages auto-encrypt if passphrase provided
- All users must use same passphrase for E2EE

### View Users
- Tap **👥** button
- 🔒 = User has E2EE enabled
- ◌ = Unknown encryption state

### Toggle Theme
- Tap **🌙** for dark mode
- Tap **☀** for light mode

---

## 🔒 Security Tips

✅ **DO:**
- Use strong passphrase (16+ characters)
- Share passphrase only in secure channels
- Verify fingerprints for new users
- Use unique passphrases per room

❌ **DON'T:**
- Share passphrase in chat
- Use simple/common passphrases
- Trust users without verification
- Reuse passphrases across rooms

---

## 🛠️ Build Variants

### Debug Build (Fast)
```bash
./gradlew assembleDebug
# Output: app/build/outputs/apk/debug/app-debug.apk (~15MB)
```

### Release Build (Optimized)
```bash
./gradlew assembleRelease
# Output: app/build/outputs/apk/release/app-release.apk (~5-8MB)
```

---

## 📋 System Requirements

- **Android:** 7.0+ (API 24)
- **RAM:** 100MB minimum
- **Storage:** 20MB free
- **Internet:** Required for WebSocket

---

## 🐛 Troubleshooting

### Build Fails
```bash
# Clean and rebuild
./gradlew clean assembleRelease
```

### Can't Connect
- Check server address (e.g., `hack.chat`)
- Verify internet connection
- Try different room name

### Messages Won't Decrypt
- Ensure all users use same passphrase
- Check room name and server match
- Verify passphrase spelling/case

### App Crashes
```bash
# View logs
adb logcat | grep "HackChat"
```

---

## 📚 Documentation

| File | Purpose |
|------|---------|
| README.md | Full features and usage |
| ARCHITECTURE.md | Technical design |
| BUILDING.md | Detailed build guide |
| PROJECT_SUMMARY.md | Project overview |

---

## 🔗 Useful Links

- **Android Studio:** https://developer.android.com/studio
- **HackChat:** https://hack.chat/
- **Android Docs:** https://developer.android.com/
- **Kotlin:** https://kotlinlang.org/

---

## ⚡ Common Commands

```bash
# Build debug APK
./gradlew assembleDebug

# Build release APK
./gradlew assembleRelease

# Clean build
./gradlew clean

# Run tests
./gradlew test

# Install on device
adb install app/build/outputs/apk/release/app-release.apk

# View logs
adb logcat

# List connected devices
adb devices
```

---

## 💡 Tips

1. **Remember Login:** Check box to save server/room/username
2. **Copy Room Link:** Tap 📋 to copy room URL
3. **Fingerprints:** Compare fingerprints to verify users
4. **Themes:** Switch themes anytime with 🌙/☀
5. **Offline:** App works offline (messages queue until connected)

---

## 📞 Need Help?

1. Check README.md for features
2. See BUILDING.md for build issues
3. Review ARCHITECTURE.md for technical details
4. Check Android logcat for errors

---

**Status:** ✅ Ready to Build
**Version:** 1.0.0
**Protocol:** HCE2EE-1
