package com.hackchat.e2ee.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

/**
 * Manages application preferences using DataStore.
 * Handles secure storage of non-sensitive login info and theme preferences.
 */
class PreferencesManager(context: Context) {

    private val dataStore = context.preferencesDataStore

    companion object {
        private const val PREFERENCES_NAME = "hackchat_prefs"
        private val SERVER_ADDRESS = stringPreferencesKey("server_address")
        private val ROOM_NAME = stringPreferencesKey("room_name")
        private val USERNAME = stringPreferencesKey("username")
        private val THEME = stringPreferencesKey("theme")
        private val REMEMBER_LOGIN = booleanPreferencesKey("remember_login")

        private val Context.preferencesDataStore by preferencesDataStore(name = PREFERENCES_NAME)
    }

    /**
     * Saves login credentials (if remember_login is enabled).
     * NEVER stores passphrase.
     */
    suspend fun saveLoginCredentials(
        serverAddress: String,
        roomName: String,
        username: String,
        rememberLogin: Boolean
    ) {
        dataStore.edit { preferences ->
            if (rememberLogin) {
                preferences[SERVER_ADDRESS] = serverAddress
                preferences[ROOM_NAME] = roomName
                preferences[USERNAME] = username
                preferences[REMEMBER_LOGIN] = true
            } else {
                // Clear stored credentials
                preferences.remove(SERVER_ADDRESS)
                preferences.remove(ROOM_NAME)
                preferences.remove(USERNAME)
                preferences[REMEMBER_LOGIN] = false
            }
        }
    }

    /**
     * Retrieves saved login credentials.
     */
    fun getLoginCredentials(): Flow<LoginPreferences> {
        return dataStore.data.map { preferences ->
            LoginPreferences(
                serverAddress = preferences[SERVER_ADDRESS] ?: "",
                roomName = preferences[ROOM_NAME] ?: "",
                username = preferences[USERNAME] ?: "",
                rememberLogin = preferences[REMEMBER_LOGIN] ?: false
            )
        }
    }

    /**
     * Saves the current theme preference.
     */
    suspend fun setTheme(theme: String) {
        dataStore.edit { preferences ->
            preferences[THEME] = theme
        }
    }

    /**
     * Retrieves the current theme preference.
     */
    fun getTheme(): Flow<String> {
        return dataStore.data.map { preferences ->
            preferences[THEME] ?: "light"
        }
    }

    /**
     * Clears all stored credentials (logout).
     */
    suspend fun clearAll() {
        dataStore.edit { preferences ->
            preferences.clear()
        }
    }
}

/**
 * Data class for login preferences.
 */
data class LoginPreferences(
    val serverAddress: String,
    val roomName: String,
    val username: String,
    val rememberLogin: Boolean
)
