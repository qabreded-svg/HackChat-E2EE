package com.hackchat.e2ee.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.hackchat.e2ee.R
import com.hackchat.e2ee.model.AppTheme
import com.hackchat.e2ee.model.LoginCredentials

@Composable
fun LoginScreen(
    onLogin: (LoginCredentials) -> Unit,
    onThemeToggle: (AppTheme) -> Unit,
    currentTheme: AppTheme,
    savedCredentials: LoginCredentials? = null
) {
    var serverAddress by remember { mutableStateOf(savedCredentials?.serverAddress ?: "") }
    var roomName by remember { mutableStateOf(savedCredentials?.roomName ?: "") }
    var username by remember { mutableStateOf(savedCredentials?.username ?: "") }
    var passphrase by remember { mutableStateOf("") }
    var rememberLogin by remember { mutableStateOf(savedCredentials?.rememberLogin ?: false) }
    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // Header
        Text(
            text = "HackChat E2EE",
            style = MaterialTheme.typography.headlineLarge,
            color = MaterialTheme.colorScheme.onBackground,
            modifier = Modifier.padding(bottom = 32.dp)
        )

        // Theme Toggle
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 24.dp),
            horizontalArrangement = Arrangement.Center
        ) {
            Button(
                onClick = { onThemeToggle(AppTheme.LIGHT) },
                modifier = Modifier.padding(end = 8.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (currentTheme == AppTheme.LIGHT)
                        MaterialTheme.colorScheme.primary else
                        MaterialTheme.colorScheme.surface
                )
            ) {
                Text("☀ Light")
            }
            Button(
                onClick = { onThemeToggle(AppTheme.DARK) },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (currentTheme == AppTheme.DARK)
                        MaterialTheme.colorScheme.primary else
                        MaterialTheme.colorScheme.surface
                )
            ) {
                Text("🌙 Dark")
            }
        }

        // Server Address
        OutlinedTextField(
            value = serverAddress,
            onValueChange = { serverAddress = it },
            label = { Text(stringResource(R.string.server_address)) },
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri)
        )

        // Room Name
        OutlinedTextField(
            value = roomName,
            onValueChange = { roomName = it },
            label = { Text(stringResource(R.string.room_name)) },
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            singleLine = true
        )

        // Username
        OutlinedTextField(
            value = username,
            onValueChange = { username = it },
            label = { Text(stringResource(R.string.username)) },
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            singleLine = true
        )

        // Passphrase
        OutlinedTextField(
            value = passphrase,
            onValueChange = { passphrase = it },
            label = { Text(stringResource(R.string.passphrase)) },
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            singleLine = true,
            visualTransformation = PasswordVisualTransformation()
        )

        // Remember Login Checkbox
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 24.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Checkbox(
                checked = rememberLogin,
                onCheckedChange = { rememberLogin = it }
            )
            Text(
                text = stringResource(R.string.remember_login),
                modifier = Modifier.padding(start = 8.dp),
                color = MaterialTheme.colorScheme.onBackground
            )
        }

        // Error Message
        if (errorMessage != null) {
            Text(
                text = errorMessage ?: "",
                color = MaterialTheme.colorScheme.error,
                modifier = Modifier.padding(bottom = 16.dp)
            )
        }

        // Join Button
        Button(
            onClick = {
                if (serverAddress.isEmpty() || roomName.isEmpty() || username.isEmpty()) {
                    errorMessage = "Please fill in all required fields"
                } else {
                    isLoading = true
                    onLogin(
                        LoginCredentials(
                            serverAddress = serverAddress,
                            roomName = roomName,
                            username = username,
                            passphrase = passphrase.ifEmpty { null },
                            rememberLogin = rememberLogin
                        )
                    )
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp),
            enabled = !isLoading
        ) {
            if (isLoading) {
                CircularProgressIndicator(
                    modifier = Modifier.size(24.dp),
                    color = MaterialTheme.colorScheme.onPrimary
                )
            } else {
                Text(stringResource(R.string.join))
            }
        }
    }
}
