package com.hackchat.e2ee.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Light Theme Colors
private val LightBackground = Color(0xFFFAFAFA)
private val LightSurface = Color(0xFFFFFFFF)
private val LightText = Color(0xFF222222)
private val LightBorder = Color(0xFFE5E5E5)

// Dark Theme Colors
private val DarkBackground = Color(0xFF1E1F22)
private val DarkSurface = Color(0xFF2A2D31)
private val DarkText = Color(0xFFE6E6E6)
private val DarkBorder = Color(0xFF3A3D42)

// Accent Color
private val AccentColor = Color(0xFF007AFF)

private val LightColorScheme = lightColorScheme(
    primary = AccentColor,
    secondary = AccentColor,
    tertiary = AccentColor,
    background = LightBackground,
    surface = LightSurface,
    onBackground = LightText,
    onSurface = LightText,
    outline = LightBorder
)

private val DarkColorScheme = darkColorScheme(
    primary = AccentColor,
    secondary = AccentColor,
    tertiary = AccentColor,
    background = DarkBackground,
    surface = DarkSurface,
    onBackground = DarkText,
    onSurface = DarkText,
    outline = DarkBorder
)

@Composable
fun HackChatE2EETheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        content = content
    )
}
