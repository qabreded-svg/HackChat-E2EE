# HackChat E2EE - Architecture Documentation

## Project Structure

```
HackChatE2EE/
├── app/
│   ├── src/
│   │   ├── main/
│   │   │   ├── kotlin/com/hackchat/e2ee/
│   │   │   │   ├── ui/
│   │   │   │   │   ├── MainActivity.kt
│   │   │   │   │   ├── screens/
│   │   │   │   │   │   ├── LoginScreen.kt
│   │   │   │   │   │   └── ChatScreen.kt
│   │   │   │   │   └── theme/
│   │   │   │   │       └── Theme.kt
│   │   │   │   ├── crypto/
│   │   │   │   │   └── CryptoUtils.kt
│   │   │   │   ├── network/
│   │   │   │   │   └── HackChatClient.kt
│   │   │   │   ├── data/
│   │   │   │   │   └── PreferencesManager.kt
│   │   │   │   └── model/
│   │   │   │       └── Models.kt
│   │   │   ├── res/
│   │   │   │   ├── values/
│   │   │   │   │   ├── strings.xml
│   │   │   │   │   ├── colors.xml
│   │   │   │   │   └── themes.xml
│   │   │   │   └── drawable/
│   │   │   └── AndroidManifest.xml
│   │   ├── test/
│   │   └── androidTest/
│   ├── build.gradle.kts
│   └── proguard-rules.pro
├── gradle/
│   └── wrapper/
│       └── gradle-wrapper.properties
├── build.gradle.kts
├── settings.gradle.kts
├── gradlew
├── README.md
└── ARCHITECTURE.md
```

## Module Breakdown

### UI Layer (`ui/`)

#### MainActivity.kt
- **Responsibility:** Main entry point and navigation controller
- **Key Features:**
  - Manages app state (logged in vs. login screen)
  - Handles theme switching
  - Integrates with PreferencesManager for persistence
  - Manages HackChatClient lifecycle
- **State Management:**
  - `currentTheme`: Current app theme (Light/Dark)
  - `isLoggedIn`: Login state
  - `currentCredentials`: Active login credentials
  - `currentFingerprint`: User's E2EE fingerprint

#### LoginScreen.kt
- **Responsibility:** User authentication and room joining
- **UI Components:**
  - Server Address input
  - Room Name input
  - Username input
  - Passphrase input (E2EE optional)
  - Remember Login checkbox
  - Theme toggle buttons
- **Validation:**
  - Ensures all required fields are filled
  - Provides error feedback
  - Shows loading state during connection

#### ChatScreen.kt
- **Responsibility:** Main chat interface
- **UI Components:**
  - **Header:** Room name, connection status, copy link, users button, theme toggle
  - **Message List:** Scrollable list of messages with timestamps, usernames, fingerprints
  - **Users Panel:** List of online users with E2EE indicators
  - **Input Bar:** Text input with send button
- **Features:**
  - Auto-scroll to latest message
  - Time formatting (HH:mm)
  - Encryption indicators (🔒)
  - User presence indicators (🔒 = E2EE, ◌ = unknown)

#### Theme.kt
- **Responsibility:** Material 3 theme definitions
- **Colors:**
  - Light: #FAFAFA background, #FFFFFF surface, #222222 text
  - Dark: #1E1F22 background, #2A2D31 surface, #E6E6E6 text
  - Accent: #007AFF (iOS blue)

### Cryptography Layer (`crypto/`)

#### CryptoUtils.kt
- **Responsibility:** All encryption/decryption operations
- **Key Functions:**

| Function | Purpose |
|----------|---------|
| `deriveKey()` | Argon2id key derivation from passphrase |
| `encrypt()` | AES-256-GCM encryption with random nonce |
| `decrypt()` | AES-256-GCM decryption with error handling |
| `generateFingerprint()` | SHA-256 fingerprint generation |
| `generateProofMessage()` | E2EE handshake proof |
| `isEncrypted()` | Check if message is encrypted |
| `isProofMessage()` | Check if message is proof message |

- **Security Practices:**
  - Uses Java's built-in crypto (javax.crypto)
  - Random nonce generation per message
  - GCM authentication tag (128-bit)
  - Proper exception handling (no plaintext leakage)

### Network Layer (`network/`)

#### HackChatClient.kt
- **Responsibility:** WebSocket communication with HackChat servers
- **Extends:** `WebSocketListener` (OkHttp)
- **Key Methods:**

| Method | Purpose |
|--------|---------|
| `connect()` | Establish WebSocket connection |
| `sendMessage()` | Send encrypted/plaintext message |
| `disconnect()` | Close connection |
| `onOpen()` | Handle connection open |
| `onMessage()` | Handle incoming messages |
| `onFailure()` | Handle connection errors |
| `onClosed()` | Handle connection closed |

- **Message Handling:**
  - Parses JSON protocol messages
  - Routes to appropriate handlers (chat, info, users, etc.)
  - Decrypts encrypted messages
  - Updates UI state via StateFlow

- **Protocol Support:**
  - `chat` - User messages
  - `info` - System information
  - `warn` - System warnings
  - `users` - User list
  - `online` / `onlineAdd` / `onlineRemove` - Presence updates

### Data Layer (`data/`)

#### PreferencesManager.kt
- **Responsibility:** Secure preference storage using DataStore
- **Stored Data:**
  - Server Address (if remember_login enabled)
  - Room Name (if remember_login enabled)
  - Username (if remember_login enabled)
  - Theme preference (light/dark)
  - Remember Login flag

- **Security:**
  - **NEVER stores passphrase**
  - Uses Android DataStore (encrypted by default)
  - Supports clearing all data on logout

### Model Layer (`model/`)

#### Models.kt
- **Data Classes:**

| Class | Purpose |
|-------|---------|
| `ChatMessage` | Represents a single message |
| `User` | Represents a user in the room |
| `ConnectionState` | Enum for connection states |
| `LoginCredentials` | Login form data |
| `AppTheme` | Enum for themes |
| `HackChatMessage` | Protocol message structure |

## Data Flow

### Login Flow
```
User Input (LoginScreen)
  ↓
MainActivity validates input
  ↓
PreferencesManager saves credentials (if enabled)
  ↓
CryptoUtils derives encryption key
  ↓
HackChatClient connects to WebSocket
  ↓
HackChatClient sends join message
  ↓
HackChatClient sends proof message (if E2EE)
  ↓
ChatScreen displays (on connection success)
```

### Message Send Flow
```
User types message (ChatScreen)
  ↓
User taps Send
  ↓
MainActivity calls hackChatClient.sendMessage()
  ↓
HackChatClient checks if encryption enabled
  ↓
If encrypted: CryptoUtils.encrypt() → [e2ee:v1]:nonce:ciphertext
  ↓
HackChatClient sends JSON message via WebSocket
  ↓
Server broadcasts to all clients
```

### Message Receive Flow
```
WebSocket receives JSON message
  ↓
HackChatClient.onMessage() parses JSON
  ↓
Routes to handler (e.g., handleChatMessage)
  ↓
If encrypted: CryptoUtils.decrypt() attempts decryption
  ↓
If decryption fails: Display "[Encrypted message - wrong passphrase]"
  ↓
Create ChatMessage object
  ↓
Update messages StateFlow
  ↓
ChatScreen recomposes with new message
```

## State Management

### Using Kotlin StateFlow

All reactive state uses `StateFlow` for efficient updates:

```kotlin
private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
val messages: StateFlow<List<ChatMessage>> = _messages

// In Compose
val messages by hackChatClient.messages.collectAsState()
```

### Scope Management

- **Main Scope:** `lifecycleScope` for lifecycle-aware coroutines
- **IO Scope:** `Dispatchers.IO` for network/crypto operations
- **Default Scope:** `Dispatchers.Default` for JSON parsing

## Security Considerations

### Passphrase Handling
- ✅ Never sent to server
- ✅ Never stored on disk
- ✅ Only kept in memory during session
- ✅ Cleared when app is destroyed

### Encryption
- ✅ AES-256-GCM (authenticated encryption)
- ✅ Random 96-bit nonce per message
- ✅ 128-bit authentication tag
- ✅ Proper exception handling (no crashes on bad input)

### Network
- ✅ WSS (WebSocket Secure) only
- ✅ No cleartext HTTP fallback
- ✅ Certificate validation enabled

### Storage
- ✅ DataStore encryption (Android 5.1+)
- ✅ Sensitive data cleared on logout
- ✅ No plaintext credentials in logs

## Performance Optimizations

1. **Lazy Message Loading:** Messages rendered on-demand via LazyColumn
2. **Coroutine Scoping:** IO operations on Dispatchers.IO
3. **StateFlow Efficiency:** Only recompose when state changes
4. **Memory Management:** Clear sensitive data after use
5. **ProGuard Minification:** Release builds optimized

## Testing Strategy

### Unit Tests
- Crypto operations (encryption/decryption)
- Key derivation
- Fingerprint generation
- Message parsing

### Integration Tests
- WebSocket connection
- Message send/receive
- State updates
- UI rendering

### Manual Testing
- Connect to public hack.chat server
- Test with/without passphrase
- Verify encryption with multiple clients
- Test theme switching
- Test remember login

## Future Enhancements

1. **Argon2id Integration:** Replace PBKDF2 with true Argon2id
2. **Message History:** Persist messages locally
3. **User Blocking:** Block specific users
4. **Emoji Support:** Full emoji keyboard
5. **File Sharing:** Encrypted file transfer
6. **Voice Messages:** Audio message support
7. **Notifications:** Push notifications for new messages
8. **Backup/Restore:** Encrypted backup of settings

## Build Configuration

### Gradle Plugins
- `com.android.application` - Android app plugin
- `kotlin("android")` - Kotlin Android plugin

### Compile Options
- **Source/Target:** Java 11
- **Kotlin JVM Target:** 11
- **Compose Compiler:** 1.5.0

### Proguard Rules
- Preserve Tink cryptography library
- Preserve OkHttp classes
- Preserve Gson classes
- Preserve app classes
- Preserve native methods
- Preserve Parcelable implementations

## Dependencies Summary

| Dependency | Version | Purpose |
|------------|---------|---------|
| androidx.core:core-ktx | 1.12.0 | Android core utilities |
| androidx.compose.ui:ui | 1.5.4 | Compose UI framework |
| androidx.compose.material3:material3 | 1.1.2 | Material 3 components |
| androidx.navigation:navigation-compose | 2.7.5 | Navigation |
| com.squareup.okhttp3:okhttp | 4.11.0 | WebSocket/HTTP |
| com.google.crypto.tink:tink-android | 1.10.0 | Cryptography |
| com.google.code.gson:gson | 2.10.1 | JSON parsing |
| kotlinx.coroutines | 1.7.3 | Async operations |
| androidx.datastore:datastore-preferences | 1.0.0 | Secure storage |

## Deployment

### Release Build
```bash
./gradlew assembleRelease
```

### Output
- APK: `app/build/outputs/apk/release/app-release.apk`
- Signed with release keystore (must be configured)

### Installation
```bash
adb install app/build/outputs/apk/release/app-release.apk
```

## Troubleshooting

### Build Fails
- Ensure Android SDK is installed
- Update gradle: `./gradlew wrapper --gradle-version 8.1`
- Clear cache: `./gradlew clean`

### Runtime Crashes
- Check logcat: `adb logcat`
- Verify permissions in AndroidManifest.xml
- Check ProGuard rules for obfuscation issues

### Encryption Issues
- Verify all users use same passphrase
- Check room name and server match
- Ensure nonce is properly random

---

**Last Updated:** 2024
**Protocol Version:** HCE2EE-1
**Target Android:** 7.0+ (API 24)
