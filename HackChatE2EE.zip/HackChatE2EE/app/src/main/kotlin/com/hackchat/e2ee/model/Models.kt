package com.hackchat.e2ee.model

import java.time.LocalDateTime

/**
 * Represents a chat message.
 */
data class ChatMessage(
    val username: String,
    val content: String,
    val timestamp: LocalDateTime = LocalDateTime.now(),
    val fingerprint: String? = null,
    val isEncrypted: Boolean = false,
    val isOwn: Boolean = false
)

/**
 * Represents a user in the chat room.
 */
data class User(
    val username: String,
    val fingerprint: String? = null,
    val hasE2EE: Boolean = false,
    val isOwn: Boolean = false
)

/**
 * Represents the connection state.
 */
enum class ConnectionState {
    DISCONNECTED,
    CONNECTING,
    CONNECTED,
    RECONNECTING,
    ERROR
}

/**
 * Represents login credentials.
 */
data class LoginCredentials(
    val serverAddress: String,
    val roomName: String,
    val username: String,
    val passphrase: String? = null,
    val rememberLogin: Boolean = false
)

/**
 * Represents application theme.
 */
enum class AppTheme {
    LIGHT,
    DARK
}

/**
 * Represents a HackChat protocol message.
 */
data class HackChatMessage(
    val cmd: String,
    val text: String? = null,
    val nick: String? = null,
    val color: String? = null,
    val trip: String? = null,
    val hash: String? = null,
    val level: Int? = null,
    val ucount: Int? = null,
    val users: List<String>? = null,
    val from: String? = null,
    val type: String? = null
)
