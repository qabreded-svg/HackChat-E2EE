package com.hackchat.e2ee.network

import android.util.Log
import com.google.gson.Gson
import com.google.gson.JsonObject
import com.hackchat.e2ee.crypto.CryptoUtils
import com.hackchat.e2ee.model.ChatMessage
import com.hackchat.e2ee.model.ConnectionState
import com.hackchat.e2ee.model.HackChatMessage
import com.hackchat.e2ee.model.User
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import java.time.LocalDateTime

/**
 * HackChat WebSocket client with HCE2EE-1 encryption support.
 */
class HackChatClient(
    private val scope: CoroutineScope
) : WebSocketListener() {

    private var webSocket: WebSocket? = null
    private val gson = Gson()
    private val client = OkHttpClient.Builder()
        .connectTimeout(java.util.concurrent.TimeUnit.SECONDS.toMillis(30).toLong(), java.util.concurrent.TimeUnit.MILLISECONDS)
        .build()

    private val _connectionState = MutableStateFlow<ConnectionState>(ConnectionState.DISCONNECTED)
    val connectionState: StateFlow<ConnectionState> = _connectionState

    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages

    private val _users = MutableStateFlow<List<User>>(emptyList())
    val users: StateFlow<List<User>> = _users

    private var encryptionKey: ByteArray? = null
    private var currentUsername: String? = null
    private var currentFingerprint: String? = null
    private var userFingerprints: MutableMap<String, String> = mutableMapOf()

    /**
     * Connects to a HackChat server.
     */
    fun connect(
        serverAddress: String,
        roomName: String,
        username: String,
        passphrase: String? = null
    ) {
        scope.launch(Dispatchers.IO) {
            try {
                _connectionState.value = ConnectionState.CONNECTING

                // Derive encryption key if passphrase provided
                if (!passphrase.isNullOrEmpty()) {
                    encryptionKey = CryptoUtils.deriveKey(passphrase, roomName, serverAddress)
                    currentFingerprint = CryptoUtils.generateFingerprint(encryptionKey!!)
                }

                currentUsername = username

                // Construct WebSocket URL
                val wsUrl = constructWebSocketUrl(serverAddress, roomName)
                Log.d(TAG, "Connecting to: $wsUrl")

                val request = Request.Builder()
                    .url(wsUrl)
                    .build()

                webSocket = client.newWebSocket(request, this@HackChatClient)

                // Send join message
                sendJoinMessage(username)

                // Send proof message if E2EE enabled
                if (encryptionKey != null) {
                    sendProofMessage()
                }
            } catch (e: Exception) {
                Log.e(TAG, "Connection error", e)
                _connectionState.value = ConnectionState.ERROR
            }
        }
    }

    /**
     * Sends a chat message.
     */
    fun sendMessage(text: String) {
        scope.launch(Dispatchers.IO) {
            try {
                val messageToSend = if (encryptionKey != null) {
                    CryptoUtils.encrypt(text, encryptionKey!!)
                } else {
                    text
                }

                val message = JsonObject().apply {
                    addProperty("cmd", "chat")
                    addProperty("text", messageToSend)
                }

                webSocket?.send(gson.toJson(message))
            } catch (e: Exception) {
                Log.e(TAG, "Error sending message", e)
            }
        }
    }

    /**
     * Disconnects from the server.
     */
    fun disconnect() {
        scope.launch(Dispatchers.IO) {
            webSocket?.close(1000, "User disconnect")
            _connectionState.value = ConnectionState.DISCONNECTED
        }
    }

    override fun onOpen(webSocket: WebSocket, response: okhttp3.Response) {
        Log.d(TAG, "WebSocket opened")
        _connectionState.value = ConnectionState.CONNECTED
    }

    override fun onMessage(webSocket: WebSocket, text: String) {
        scope.launch(Dispatchers.Default) {
            try {
                val jsonObject = gson.fromJson(text, JsonObject::class.java)
                val cmd = jsonObject.get("cmd")?.asString ?: return@launch

                when (cmd) {
                    "chat" -> handleChatMessage(jsonObject)
                    "info" -> handleInfoMessage(jsonObject)
                    "warn" -> handleWarnMessage(jsonObject)
                    "users" -> handleUsersMessage(jsonObject)
                    "online" -> handleOnlineMessage(jsonObject)
                    "onlineAdd" -> handleOnlineAddMessage(jsonObject)
                    "onlineRemove" -> handleOnlineRemoveMessage(jsonObject)
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error parsing message", e)
            }
        }
    }

    override fun onFailure(webSocket: WebSocket, t: Throwable, response: okhttp3.Response?) {
        Log.e(TAG, "WebSocket failure", t)
        _connectionState.value = ConnectionState.ERROR
    }

    override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
        Log.d(TAG, "WebSocket closed: $code $reason")
        _connectionState.value = ConnectionState.DISCONNECTED
    }

    private fun handleChatMessage(json: JsonObject) {
        val nick = json.get("nick")?.asString ?: "Unknown"
        val text = json.get("text")?.asString ?: ""
        val trip = json.get("trip")?.asString

        // Try to decrypt if encrypted
        val decryptedText = if (CryptoUtils.isEncrypted(text)) {
            if (encryptionKey != null) {
                CryptoUtils.decrypt(text, encryptionKey!!) ?: "[Encrypted message - wrong passphrase]"
            } else {
                text
            }
        } else {
            text
        }

        val fingerprint = userFingerprints[nick] ?: currentFingerprint

        val message = ChatMessage(
            username = nick,
            content = decryptedText,
            timestamp = LocalDateTime.now(),
            fingerprint = fingerprint,
            isEncrypted = CryptoUtils.isEncrypted(text),
            isOwn = nick == currentUsername
        )

        _messages.value = _messages.value + message
    }

    private fun handleInfoMessage(json: JsonObject) {
        val text = json.get("text")?.asString ?: ""
        val message = ChatMessage(
            username = "INFO",
            content = text,
            timestamp = LocalDateTime.now(),
            isOwn = false
        )
        _messages.value = _messages.value + message
    }

    private fun handleWarnMessage(json: JsonObject) {
        val text = json.get("text")?.asString ?: ""
        val message = ChatMessage(
            username = "WARN",
            content = text,
            timestamp = LocalDateTime.now(),
            isOwn = false
        )
        _messages.value = _messages.value + message
    }

    private fun handleUsersMessage(json: JsonObject) {
        val users = json.getAsJsonArray("users")?.map { it.asString } ?: emptyList()
        updateUsersList(users)
    }

    private fun handleOnlineMessage(json: JsonObject) {
        val nick = json.get("nick")?.asString ?: return
        val users = _users.value.toMutableList()
        if (!users.any { it.username == nick }) {
            users.add(User(username = nick, hasE2EE = false))
            _users.value = users
        }
    }

    private fun handleOnlineAddMessage(json: JsonObject) {
        val nick = json.get("nick")?.asString ?: return
        val users = _users.value.toMutableList()
        if (!users.any { it.username == nick }) {
            users.add(User(username = nick, hasE2EE = false))
            _users.value = users
        }
    }

    private fun handleOnlineRemoveMessage(json: JsonObject) {
        val nick = json.get("nick")?.asString ?: return
        val users = _users.value.filter { it.username != nick }
        _users.value = users
    }

    private fun updateUsersList(usernames: List<String>) {
        val users = usernames.map { username ->
            User(
                username = username,
                fingerprint = userFingerprints[username],
                hasE2EE = userFingerprints.containsKey(username),
                isOwn = username == currentUsername
            )
        }
        _users.value = users
    }

    private fun sendJoinMessage(username: String) {
        val message = JsonObject().apply {
            addProperty("cmd", "join")
            addProperty("nick", username)
        }
        webSocket?.send(gson.toJson(message))
    }

    private fun sendProofMessage() {
        if (encryptionKey == null) return

        try {
            val proofMessage = CryptoUtils.generateProofMessage(encryptionKey!!)
            val message = JsonObject().apply {
                addProperty("cmd", "chat")
                addProperty("text", proofMessage)
            }
            webSocket?.send(gson.toJson(message))
        } catch (e: Exception) {
            Log.e(TAG, "Error sending proof message", e)
        }
    }

    private fun constructWebSocketUrl(serverAddress: String, roomName: String): String {
        val baseUrl = serverAddress.removePrefix("https://").removePrefix("http://")
        return "wss://$baseUrl/socket.io/?EIO=4&transport=websocket&room=$roomName"
    }

    companion object {
        private const val TAG = "HackChatClient"
    }
}
