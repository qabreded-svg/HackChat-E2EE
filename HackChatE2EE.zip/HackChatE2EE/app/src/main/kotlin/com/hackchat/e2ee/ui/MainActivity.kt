package com.hackchat.e2ee.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.*
import androidx.lifecycle.lifecycleScope
import com.hackchat.e2ee.data.PreferencesManager
import com.hackchat.e2ee.model.AppTheme
import com.hackchat.e2ee.model.ConnectionState
import com.hackchat.e2ee.model.LoginCredentials
import com.hackchat.e2ee.network.HackChatClient
import com.hackchat.e2ee.ui.screens.ChatScreen
import com.hackchat.e2ee.ui.screens.LoginScreen
import com.hackchat.e2ee.ui.theme.HackChatE2EETheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private lateinit var preferencesManager: PreferencesManager
    private lateinit var hackChatClient: HackChatClient

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        preferencesManager = PreferencesManager(this)
        hackChatClient = HackChatClient(lifecycleScope)

        setContent {
            var currentTheme by remember { mutableStateOf(AppTheme.LIGHT) }
            var isLoggedIn by remember { mutableStateOf(false) }
            var currentCredentials by remember { mutableStateOf<LoginCredentials?>(null) }
            var currentFingerprint by remember { mutableStateOf<String?>(null) }

            // Load theme preference
            LaunchedEffect(Unit) {
                preferencesManager.getTheme().collect { theme ->
                    currentTheme = if (theme == "dark") AppTheme.DARK else AppTheme.LIGHT
                }
            }

            // Load saved credentials
            var savedCredentials by remember { mutableStateOf<LoginCredentials?>(null) }
            LaunchedEffect(Unit) {
                preferencesManager.getLoginCredentials().collect { prefs ->
                    if (prefs.rememberLogin) {
                        savedCredentials = LoginCredentials(
                            serverAddress = prefs.serverAddress,
                            roomName = prefs.roomName,
                            username = prefs.username,
                            rememberLogin = true
                        )
                    }
                }
            }

            // Collect connection state and messages from HackChat client
            val connectionState by hackChatClient.connectionState.collectAsState()
            val messages by hackChatClient.messages.collectAsState()
            val users by hackChatClient.users.collectAsState()

            HackChatE2EETheme(darkTheme = currentTheme == AppTheme.DARK) {
                if (isLoggedIn && currentCredentials != null) {
                    ChatScreen(
                        roomName = currentCredentials!!.roomName,
                        username = currentCredentials!!.username,
                        fingerprint = currentFingerprint,
                        messages = messages,
                        users = users,
                        connectionState = connectionState,
                        onSendMessage = { message ->
                            hackChatClient.sendMessage(message)
                        },
                        onBack = {
                            isLoggedIn = false
                            hackChatClient.disconnect()
                            lifecycleScope.launch {
                                preferencesManager.clearAll()
                            }
                        },
                        onThemeToggle = {
                            currentTheme = if (currentTheme == AppTheme.LIGHT) AppTheme.DARK else AppTheme.LIGHT
                            lifecycleScope.launch {
                                preferencesManager.setTheme(
                                    if (currentTheme == AppTheme.DARK) "dark" else "light"
                                )
                            }
                        }
                    )
                } else {
                    LoginScreen(
                        onLogin = { credentials ->
                            currentCredentials = credentials
                            currentFingerprint = null // Will be set by crypto utils
                            isLoggedIn = true

                            // Save credentials if remember login is enabled
                            lifecycleScope.launch {
                                preferencesManager.saveLoginCredentials(
                                    credentials.serverAddress,
                                    credentials.roomName,
                                    credentials.username,
                                    credentials.rememberLogin
                                )
                            }

                            // Connect to HackChat server
                            hackChatClient.connect(
                                serverAddress = credentials.serverAddress,
                                roomName = credentials.roomName,
                                username = credentials.username,
                                passphrase = credentials.passphrase
                            )
                        },
                        onThemeToggle = { theme ->
                            currentTheme = theme
                            lifecycleScope.launch {
                                preferencesManager.setTheme(
                                    if (theme == AppTheme.DARK) "dark" else "light"
                                )
                            }
                        },
                        currentTheme = currentTheme,
                        savedCredentials = savedCredentials
                    )
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        hackChatClient.disconnect()
    }
}
