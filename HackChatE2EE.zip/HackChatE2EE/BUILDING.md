# Building HackChat E2EE APK

Complete guide to building the native Android application from source.

## System Requirements

### Minimum
- **OS:** Windows 10+, macOS 10.14+, Linux (Ubuntu 18.04+)
- **RAM:** 8GB (16GB recommended)
- **Disk:** 10GB free space
- **Java:** OpenJDK 11+

### Android Development Tools
- **Android Studio:** Latest version (2023.1.1+)
- **Android SDK:** API 34 (Android 14)
- **Build Tools:** 34.0.0+
- **NDK:** Not required (pure Java/Kotlin)

## Installation

### 1. Install Android Studio

#### Windows/Mac
- Download from https://developer.android.com/studio
- Run installer and follow on-screen instructions
- Accept Android SDK license agreements

#### Linux (Ubuntu)
```bash
sudo apt-get update
sudo apt-get install android-studio
```

### 2. Install Android SDK

In Android Studio:
1. **Tools** → **SDK Manager**
2. **SDK Platforms** tab:
   - ✅ Android 14 (API 34)
   - ✅ Android 13 (API 33) - Optional
3. **SDK Tools** tab:
   - ✅ Android SDK Build-Tools 34.0.0
   - ✅ Android Emulator (optional)
   - ✅ Android SDK Platform-Tools
4. Click **Apply** → **OK**

### 3. Configure Java

Ensure JAVA_HOME is set:

**Windows (PowerShell):**
```powershell
$env:JAVA_HOME = "C:\Program Files\Android\Android Studio\jbr"
```

**macOS/Linux:**
```bash
export JAVA_HOME=$(/usr/libexec/java_home -v 11)
# Add to ~/.bashrc or ~/.zshrc for persistence
```

## Building from Command Line

### Quick Start

```bash
# Navigate to project
cd HackChatE2EE

# Build debug APK
./gradlew assembleDebug

# Build release APK
./gradlew assembleRelease
```

### Detailed Steps

#### 1. Clone/Extract Project
```bash
# If cloning from git
git clone <repository-url> HackChatE2EE
cd HackChatE2EE

# Or extract from archive
unzip HackChatE2EE.zip
cd HackChatE2EE
```

#### 2. Configure Local SDK Path

Create `local.properties`:
```bash
# macOS/Linux
echo "sdk.dir=$ANDROID_HOME" > local.properties

# Windows (PowerShell)
"sdk.dir=$env:ANDROID_SDK_ROOT" | Out-File local.properties
```

Or manually edit `local.properties`:
```properties
sdk.dir=/Users/username/Library/Android/sdk          # macOS
sdk.dir=/home/username/Android/Sdk                   # Linux
sdk.dir=C:\\Users\\username\\AppData\\Local\\Android\\Sdk  # Windows
```

#### 3. Build Debug APK

```bash
./gradlew assembleDebug
```

**Output:** `app/build/outputs/apk/debug/app-debug.apk`

**Time:** ~2-5 minutes (first build slower due to dependency download)

#### 4. Build Release APK

```bash
./gradlew assembleRelease
```

**Output:** `app/build/outputs/apk/release/app-release.apk`

**Note:** First release build requires keystore configuration (see below)

### Gradle Commands Reference

| Command | Purpose |
|---------|---------|
| `./gradlew build` | Build all variants |
| `./gradlew assembleDebug` | Build debug APK |
| `./gradlew assembleRelease` | Build release APK |
| `./gradlew clean` | Clean build artifacts |
| `./gradlew test` | Run unit tests |
| `./gradlew connectedAndroidTest` | Run instrumented tests |
| `./gradlew lint` | Run Android lint checks |
| `./gradlew dependencies` | Show dependency tree |

## Building in Android Studio

### 1. Open Project

1. **File** → **Open**
2. Select `HackChatE2EE` directory
3. Wait for Gradle sync to complete

### 2. Build Menu

**Build** → **Build Bundle(s) / APK(s)** → **Build APK(s)**

### 3. Monitor Build

- **Build** output appears in bottom panel
- Watch for errors/warnings
- Build completes when you see "Build completed successfully"

### 4. Locate APK

**Build** → **Analyze APK** → Select APK from:
- Debug: `app/build/outputs/apk/debug/`
- Release: `app/build/outputs/apk/release/`

## Release Build Configuration

### Create Keystore (First Time Only)

```bash
# Generate keystore
keytool -genkey -v -keystore hackchat-release.keystore \
  -keyalg RSA -keysize 2048 -validity 10000 \
  -alias hackchat-key

# You'll be prompted for:
# - Keystore password
# - Key password
# - Certificate details (name, organization, etc.)
```

### Configure Gradle

Edit `app/build.gradle.kts`:

```kotlin
android {
    signingConfigs {
        create("release") {
            storeFile = file("../hackchat-release.keystore")
            storePassword = "your_keystore_password"
            keyAlias = "hackchat-key"
            keyPassword = "your_key_password"
        }
    }

    buildTypes {
        release {
            signingConfig = signingConfigs.getByName("release")
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
}
```

### Build Signed Release APK

```bash
./gradlew assembleRelease
```

Output: `app/build/outputs/apk/release/app-release.apk` (signed and optimized)

## Installation on Device

### Prerequisites

- Android device with USB debugging enabled
- USB cable
- ADB installed (`adb` command available)

### Enable USB Debugging

1. **Settings** → **Developer Options**
2. Enable **USB Debugging**
3. Connect device via USB
4. Tap **Allow** on device permission prompt

### Install APK

```bash
# Install debug APK
adb install app/build/outputs/apk/debug/app-debug.apk

# Install release APK
adb install app/build/outputs/apk/release/app-release.apk

# Reinstall (replace existing)
adb install -r app/build/outputs/apk/release/app-release.apk
```

### Verify Installation

```bash
adb shell pm list packages | grep hackchat
# Output: package:com.hackchat.e2ee
```

### Launch App

```bash
adb shell am start -n com.hackchat.e2ee/.ui.MainActivity
```

### View Logs

```bash
adb logcat | grep "HackChat"
```

## Testing

### Unit Tests

```bash
./gradlew test
```

Tests run on local JVM (no device needed)

### Instrumented Tests

```bash
# Connect device/emulator first
./gradlew connectedAndroidTest
```

### Manual Testing Checklist

- [ ] App launches without crash
- [ ] Login screen displays correctly
- [ ] Can join a public room (hack.chat/?meta)
- [ ] Can send plaintext messages
- [ ] Can send encrypted messages (with passphrase)
- [ ] Messages display with correct formatting
- [ ] User list shows online users
- [ ] Theme toggle works (light/dark)
- [ ] Remember login saves credentials
- [ ] Disconnecting returns to login screen
- [ ] App handles network errors gracefully

## Troubleshooting

### Build Fails: "SDK location not found"

**Solution:**
```bash
echo "sdk.dir=$ANDROID_HOME" > local.properties
# Or manually create local.properties with correct path
```

### Build Fails: "Unsupported Java version"

**Solution:**
```bash
# Check Java version
java -version

# Ensure Java 11+
export JAVA_HOME=$(/usr/libexec/java_home -v 11)
```

### Build Fails: "Gradle sync failed"

**Solution:**
1. **File** → **Sync Now**
2. Or: `./gradlew --refresh-dependencies`
3. Or: Delete `.gradle` folder and rebuild

### Build Slow

**Optimization:**
```bash
# Use daemon (default)
./gradlew assembleDebug

# Parallel builds
./gradlew assembleDebug --parallel

# Offline mode (if dependencies cached)
./gradlew assembleDebug --offline
```

### APK Installation Fails: "INSTALL_FAILED_INVALID_APK"

**Solution:**
- Ensure APK is properly signed
- Try: `adb install -r app/build/outputs/apk/release/app-release.apk`
- Check device storage space

### App Crashes on Launch

**Debug:**
```bash
adb logcat -c
adb shell am start -n com.hackchat.e2ee/.ui.MainActivity
adb logcat | grep "E/AndroidRuntime"
```

### ProGuard Obfuscation Issues

**Solution:** Disable minification for debug:
```kotlin
debug {
    isMinifyEnabled = false
}
```

## Performance Optimization

### Reduce Build Time

```bash
# Gradle daemon (enabled by default)
org.gradle.daemon=true

# Parallel builds
org.gradle.parallel=true

# Increase heap size
org.gradle.jvmargs=-Xmx4096m
```

### Reduce APK Size

- Release builds use ProGuard minification
- Current size: ~5-8MB (depends on dependencies)
- Use `./gradlew bundleRelease` for Google Play (smaller)

### Optimize for Device

```bash
# Build for specific ABI (faster)
./gradlew assembleDebug -Pabi=arm64-v8a
```

## Distribution

### Google Play Store

1. **Create signed APK** (see Release Build Configuration)
2. **Create Google Play account**
3. **Upload APK** to Google Play Console
4. **Configure store listing** (screenshots, description, etc.)
5. **Submit for review**

### Direct Distribution

1. Build signed release APK
2. Host on web server or file sharing
3. Share download link
4. Users install via: `adb install <url>`

### GitHub Releases

```bash
# Tag release
git tag v1.0.0

# Push tag
git push origin v1.0.0

# Upload APK to GitHub Releases
# (via web interface or gh CLI)
```

## CI/CD Integration

### GitHub Actions Example

```yaml
name: Build APK

on:
  push:
    branches: [ main ]
  pull_request:
    branches: [ main ]

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - uses: actions/setup-java@v2
        with:
          java-version: '11'
      - run: ./gradlew assembleRelease
      - uses: actions/upload-artifact@v2
        with:
          name: app-release.apk
          path: app/build/outputs/apk/release/app-release.apk
```

## Next Steps

1. **Build the APK** using instructions above
2. **Test on device** using manual testing checklist
3. **Configure release signing** for production builds
4. **Distribute** via Google Play or direct download
5. **Monitor** crash reports and user feedback

## Support

For build issues:
1. Check Android Studio **Build** output
2. Review `app/build/gradle.kts` configuration
3. Check `local.properties` SDK path
4. Run `./gradlew clean` and rebuild
5. Check Android documentation: https://developer.android.com/

---

**Last Updated:** 2024
**Gradle Version:** 8.1
**Android SDK:** 34 (Android 14)
